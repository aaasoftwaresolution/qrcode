import React from "react";

export default function Header() {
  return (
    <div>
      <div className="container2 d-flex justify-content-center" data-aos="zoom-in">
        <img
          className="img-fluid"
          src="images/header2.jpg"
          alt="restaurant bg"
        />
      </div>
    </div>
  );
}
